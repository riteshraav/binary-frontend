import 'package:hive/hive.dart';

part 'rate_entry.g.dart';

@HiveType(typeId: 1)
class RateEntry extends HiveObject {
  @HiveField(0)
  final String animal;

  @HiveField(1)
  final double fat;

  @HiveField(2)
  final double snf;

  @HiveField(3)
  final double rate;

  RateEntry({
    required this.animal,
    required this.fat,
    required this.snf,
    required this.rate,
  });
}
