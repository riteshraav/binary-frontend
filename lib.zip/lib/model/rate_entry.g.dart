// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'rate_entry.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class RateEntryAdapter extends TypeAdapter<RateEntry> {
  @override
  final int typeId = 1;

  @override
  RateEntry read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return RateEntry(
      animal: fields[0] as String,
      fat: fields[1] as double,
      snf: fields[2] as double,
      rate: fields[3] as double,
    );
  }

  @override
  void write(BinaryWriter writer, RateEntry obj) {
    writer
      ..writeByte(4)
      ..writeByte(0)
      ..write(obj.animal)
      ..writeByte(1)
      ..write(obj.fat)
      ..writeByte(2)
      ..write(obj.snf)
      ..writeByte(3)
      ..write(obj.rate);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RateEntryAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
