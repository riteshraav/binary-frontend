import 'package:flutter/material.dart';
import 'package:windows_sample/aavak_report_window.dart';
import 'package:windows_sample/milk_collection_window.dart';
import 'package:windows_sample/other_window.dart';
import 'package:windows_sample/screens/local_master_screen.dart';
import 'package:windows_sample/theme/app_theme.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);  // Added const constructor

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'File Explorer',
      home:  FileExplorerPage(),  // Added const
    );
  }
}

class FileExplorerPage extends StatefulWidget {
  @override
  _FileExplorerPageState createState() => _FileExplorerPageState();
}

class _FileExplorerPageState extends State<FileExplorerPage>
    with TickerProviderStateMixin {
  String? selectedFilePath;
  bool isLoading = false;
  String fileContent = "";
  late AnimationController _tabController;
  late Animation<double> _tabAnimation;
  int selectedTabIndex = 0;
  Map<String, bool> expansionStates = {};

  final List<Map<String, dynamic>> menuServices = [
    {"icon": "assets/logo.png", "title": "Billing"},
    {"icon": "assets/rate.png", "title": "Accounting"},
    {"icon": "assets/sell.png", "title": "Other"},
  ];


  final List<Map<String, dynamic>> services = [
    {
      "title": "दुध संकलन",
      "icon": 'assets/milk-can.png',
      "isImage": true,
      "color": Colors.lightBlueAccent
    },
    {
      "title": "स्थानिक दुध विक्री नोंद",
      "icon": 'assets/milk-box.png',
      "isImage": true,
      "color": Colors.greenAccent
    },
    {
      "title": "कपाती भरणे",
      "icon": 'assets/rupee.png',
      "isImage": true,
      "color": Colors.orangeAccent
    },
    {
      "title": "रिपोर्ट्स",
      "icon": 'assets/report.png',
      "isImage": true,
      "color": Colors.deepPurpleAccent
    },
    {
      "title": "उत्पाद्काची माहिती भरणे",
      "icon": 'assets/group.png',
      "isImage": true,
      "color": Color(0xFFA47DAB)
    },
  ];

  List<String> mainMenuList = ['Billing', 'Accounting', 'Other'];
  List<String> subMenuList = ['Mahiti Bharane', 'Reports', 'Other'];

  Map<String, Map<String, Map<String, StatefulWidget>>> billingMenu = {
    'बिलिंग सिस्टीम': {
      'माहिती भरणे': {'दुध संकलन': MilkCollectionWindow()},
      'रिपोर्ट्स': {'आवक रेपोर्ट': AavakReportWindow()},
      'इतर': {'इतर': OtherWindow()}
    },
  };

  Map<String, Map<String, Map<String, StatefulWidget>>> accountingMenu = {
    'अक्कौटिंग सिस्टीम': {
      'माहिती भरणे': {'दुध संकलन': MilkCollectionWindow()},
      'रिपोर्ट्स': {'आवक रेपोर्ट': AavakReportWindow()},
      'इतर': {'इतर': OtherWindow()}
    },
  };

  Map<String, Map<String, Map<String, StatefulWidget>>> otherMenu = {
    'इतर': {
      'माहिती भरणे': {'दुध संकलन': MilkCollectionWindow()},
      'रिपोर्ट्स': {'आवक रेपोर्ट': AavakReportWindow()},
      'इतर': {'इतर': OtherWindow()}
    },
  };

  @override
  void initState() {
    super.initState();
    _tabController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _tabAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _tabController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Widget _buildTabIcon(int index, String icon, String label) {
    final isSelected = selectedTabIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedTabIndex = index;
          });
          _tabController.forward(from: 0);
        },
        child: Container(
          height: 50,
          padding: EdgeInsets.symmetric(horizontal: 8),
          decoration: isSelected
              ? BoxDecoration(
            color: Colors.blue[50],
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(8), topRight: Radius.circular(8)),
          )
              : null,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                height: 28,
                icon,
                color: isSelected ? Colors.blue : Colors.white,
              ),
              SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  fontSize: 10,
                  color: isSelected ? Colors.blue : Colors.white,
                  fontWeight: isSelected ? FontWeight.w500 : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDirectoryStructure(Map<String, dynamic> menu,
      {bool isRoot = false, String parentPath = ''}) {
    final items = menu.entries.map((entry) {
      final key = entry.key;
      final value = entry.value;
      final currentPath = parentPath.isEmpty ? key : '$parentPath/$key';

      if (value is Map<String, dynamic>) {
        return Theme(
          data: Theme.of(context).copyWith(
            dividerColor: Colors.transparent,
          ),
          child: ExpansionTile(
            key: Key(currentPath),
            tilePadding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 0.0),
            childrenPadding: EdgeInsets.only(left: 16.0),
            visualDensity: VisualDensity.compact,
            dense: true,
            minTileHeight: 32.0,
            trailing: const SizedBox.shrink(),
            leading: AnimatedRotation(
              duration: Duration(milliseconds: 200),
              turns: (expansionStates[currentPath] ?? false) ? 0.25 : 0.0,
              child: Icon(
                Icons.keyboard_arrow_right,
                size: 16,
                color: AppTheme.primaryBlack,
              ),
            ),
            onExpansionChanged: (expanded) {
              setState(() {
                expansionStates[currentPath] = expanded;
              });
            },
            title: Text(
              key,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w400,
              ),
              overflow: TextOverflow.ellipsis,
            ),
            children: [
              _buildDirectoryStructure(value,
                  isRoot: false, parentPath: currentPath),
            ],
          ),
        );
      } else if (value is StatefulWidget) {
        return ListTile(
          dense: true,
          visualDensity: VisualDensity.compact,
          minTileHeight: 28.0,
          contentPadding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 0.0),
          leading: const Icon(Icons.insert_drive_file,
              color: Colors.black45, size: 14),
          title: Text(
            key,
            style: const TextStyle(
              fontSize: 13,
              color: Colors.black,
            ),
            overflow: TextOverflow.ellipsis,
          ),
          onTap: () {
            setState(() {
              selectedFilePath = key;
              fileContent = 'Content for $key';
            });
            print('Opening $key');
          },
        );
      }
      return const SizedBox();
    }).toList();

    return isRoot
        ? Column(
      mainAxisSize: MainAxisSize.min,
      children: items,
    )
        : Column(
      mainAxisSize: MainAxisSize.min,
      children: items,
    );
  }

  Widget _buildHomeContent(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Binary Solutions',
        theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2196F3),
          scaffoldBackgroundColor: const Color(0xFFEFF6FF),
            cardTheme: const CardThemeData(
            elevation: 1.5,
          margin: EdgeInsets.all(12),
          shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.all(Radius.circular(16)),
    ),
    ),

        ),
      home: LocalMasterScreen(),  // Without const
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(100),
        child: AppBar(
          backgroundColor: AppTheme.primaryBlue,
          elevation: 0,
          leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.ac_unit, color: Colors.white),
          ),
          flexibleSpace: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 56,
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    SizedBox(width: 56),
                    Text(
                      'Binary Solutions',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                height: 44,
                child: Row(
                  children: [
                    for (int i = 0; i < menuServices.length; i++)
                      _buildTabIcon(
                          i, menuServices[i]['icon'], menuServices[i]['title']),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      body: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              color: AppTheme.backgroundSecondary,
              border: Border(right: BorderSide(color: Colors.black)),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildDirectoryStructure(billingMenu,
                      isRoot: true, parentPath: 'section1'),
                  SizedBox(height: 8),
                  _buildDirectoryStructure(accountingMenu,
                      isRoot: true, parentPath: 'section2'),
                  SizedBox(height: 8),
                  _buildDirectoryStructure(otherMenu,
                      isRoot: true, parentPath: 'section3'),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ),

          // ✅ Don't use "child:" here, just Expanded inside Row's children
          Expanded(
            child: Container(
              color: AppTheme.backgroundSecondary,
              child: selectedFilePath != null
                  ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.backgroundSecondary,
                      border: Border(bottom: BorderSide(color: Colors.black)),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.insert_drive_file,
                          size: 16,
                          color: AppTheme.primaryBlack,
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            selectedFilePath!,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: isLoading
                        ? Center(child: CircularProgressIndicator())
                        : SingleChildScrollView(
                      padding: EdgeInsets.all(16),
                      child: SelectableText(
                        fileContent,
                        style: TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 12,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                    ),
                  ),
                ],
              )
                  : Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.description,
                      size: 64,
                      color: Colors.blueAccent,
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Select a file to view its contents',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),

    );
  }
}