import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../model/rate_entry.dart';

import '../services/excel_import_service.dart';
import '../services/rate_finder.dart';

class LocalMasterScreen extends StatefulWidget {
  const LocalMasterScreen({super.key});

  @override
  State<LocalMasterScreen> createState() => _LocalMasterScreenState();
}

class _LocalMasterScreenState extends State<LocalMasterScreen> {
  String? _pickedFileName;
  bool _busy = false;

  final _fatCtrl = TextEditingController();
  final _snfCtrl = TextEditingController();
  String _animal = 'cow';
  double? _foundRate;

  @override
  void dispose() {
    _fatCtrl.dispose();
    _snfCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickAndImport() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: false,
      type: FileType.custom,
      allowedExtensions: const ['xlsx', 'xls'],
      withData: false,
    );
    if (result == null || result.files.isEmpty) return;

    final path = result.files.single.path;
    if (path == null) return;

    setState(() {
      _pickedFileName = result.files.single.name;
      _busy = true;
    });

    try {
      final inserted = await ExcelImportService.importRatesFromExcel(File(path));
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Imported $inserted rows from $_pickedFileName')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to import: $e')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _findRate() {
    final fat = double.tryParse(_fatCtrl.text.trim());
    final snf = double.tryParse(_snfCtrl.text.trim());
    if (fat == null || snf == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter valid Fat and SNF')),
      );
      return;
    }
    final rate = RateFinder.findRate(animal: _animal, fat: fat, snf: snf);
    setState(() => _foundRate = rate);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _TopTabsBar(),
      body: Row(
        children: [
          // Left menu placeholder (if you already have your own drawer/rail, remove this)
          _SideNav(onOpenLocalMaster: () {}, current: 'लोकल मास्टर'),
          // Content
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: ListView(
                children: [
                  _Header(title: 'दूध संकलन  •  लोकल मास्टर'),
                  _UploadCard(
                    busy: _busy,
                    pickedFileName: _pickedFileName,
                    onPick: _pickAndImport,
                  ),
                  _FinderCard(
                    animal: _animal,
                    onAnimalChanged: (v) => setState(() => _animal = v),
                    fatCtrl: _fatCtrl,
                    snfCtrl: _snfCtrl,
                    onFind: _findRate,
                    foundRate: _foundRate,
                  ),
                  _PreviewCard(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TopTabsBar extends StatelessWidget implements PreferredSizeWidget {
  @override
  Size get preferredSize => const Size.fromHeight(64);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: const Text('Binary Solutions'),
      centerTitle: false,
    );
  }
}

class _SideNav extends StatelessWidget {
  final VoidCallback onOpenLocalMaster;
  final String current;
  const _SideNav({required this.onOpenLocalMaster, required this.current});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240,
      color: const Color(0xFF2196F3),
      child: ListView(
        padding: const EdgeInsets.only(top: 8),
        children: [
          const ListTile(
            leading: Icon(Icons.receipt_long, color: Colors.white),
            title: Text('बिलिंग सिस्टम', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          ),
          _NavItem(
            icon: Icons.storage,
            label: 'लोकल मास्टर',
            selected: true,
            onTap: onOpenLocalMaster,
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: Colors.white),
      title: Text(label, style: const TextStyle(color: Colors.white)),
      selected: selected,
      selectedTileColor: Colors.white24,
      onTap: onTap,
    );
  }
}

class _Header extends StatelessWidget {
  final String title;
  const _Header({required this.title});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 4, 6, 8),
      child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
    );
  }
}

class _UploadCard extends StatelessWidget {
  final bool busy;
  final String? pickedFileName;
  final VoidCallback onPick;
  const _UploadCard({required this.busy, required this.pickedFileName, required this.onPick});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Upload Excel File', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Row(
              children: [
                FilledButton.icon(
                  onPressed: busy ? null : onPick,
                  icon: const Icon(Icons.file_upload),
                  label: const Text('Choose .xlsx / .xls'),
                ),
                const SizedBox(width: 12),
                if (pickedFileName != null) Text(pickedFileName!, style: const TextStyle(fontStyle: FontStyle.italic)),
                if (busy) const Padding(
                  padding: EdgeInsets.only(left: 12),
                  child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text('Only Excel files are allowed. The sheet should contain columns: animal, fat, snf, rate.'),
          ],
        ),
      ),
    );
  }
}

class _FinderCard extends StatelessWidget {
  final String animal;
  final void Function(String) onAnimalChanged;
  final TextEditingController fatCtrl;
  final TextEditingController snfCtrl;
  final VoidCallback onFind;
  final double? foundRate;

  const _FinderCard({
    required this.animal,
    required this.onAnimalChanged,
    required this.fatCtrl,
    required this.snfCtrl,
    required this.onFind,
    required this.foundRate,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Rate Finder', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                DropdownButton<String>(
                  value: animal,
                  items: const [
                    DropdownMenuItem(value: 'cow', child: Text('गाय (Cow)')),
                    DropdownMenuItem(value: 'buffalo', child: Text('म्हैस (Buffalo)')),
                  ],
                  onChanged: (v) => v == null ? null : onAnimalChanged(v),
                ),
                SizedBox(
                  width: 120,
                  child: TextField(
                    controller: fatCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'Fat'),
                  ),
                ),
                SizedBox(
                  width: 120,
                  child: TextField(
                    controller: snfCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'SNF'),
                  ),
                ),
                FilledButton.icon(
                  onPressed: onFind,
                  icon: const Icon(Icons.search),
                  label: const Text('Find Rate'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (foundRate != null)
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.green.shade50,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.currency_rupee),
                    Text(
                      foundRate!.toStringAsFixed(2),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              )
            else
              const Text('Enter Fat & SNF and press Find Rate.'),
          ],
        ),
      ),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final box = Hive.box<RateEntry>('rateBox');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Cached Rates (first 10)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          ValueListenableBuilder(
            valueListenable: box.listenable(),
            builder: (context, Box<RateEntry> b, _) {
              final items = b.values.toList().take(10).toList();
              if (items.isEmpty) return const Text('No data. Upload an Excel file to cache rates.');
              return SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('Animal')),
                    DataColumn(label: Text('Fat')),
                    DataColumn(label: Text('SNF')),
                    DataColumn(label: Text('Rate')),
                  ],
                  rows: [
                    for (final e in items)
                      DataRow(cells: [
                        DataCell(Text(e.animal)),
                        DataCell(Text(e.fat.toString())),
                        DataCell(Text(e.snf.toString())),
                        DataCell(Text(e.rate.toString())),
                      ]),
                  ],
                ),
              );
            },
          ),
        ]),
      ),
    );
  }
}
