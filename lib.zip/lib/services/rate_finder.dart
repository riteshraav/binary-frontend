import 'dart:math';
import 'package:hive/hive.dart';
import '../model/rate_entry.dart';


class RateFinder {
  /// Exact match → return
  /// Else nearest neighbour by (fat,snf) Euclidean distance within the same animal.
  static double? findRate({
    required String animal, // "cow" | "buffalo"
    required double fat,
    required double snf,
  }) {
    final box = Hive.box<RateEntry>('rateBox');
    if (box.isEmpty) return null;

    RateEntry? exact;
    final List<RateEntry> same = [];

    for (final e in box.values) {
      if (e.animal != animal) continue;
      same.add(e);
      if ((e.fat - fat).abs() < 1e-9 && (e.snf - snf).abs() < 1e-9) {
        exact = e;
      }
    }

    if (same.isEmpty) return null;
    if (exact != null) return exact.rate;

    // nearest neighbour
    same.sort((a, b) {
      final da = pow(a.fat - fat, 2) + pow(a.snf - snf, 2);
      final db = pow(b.fat - fat, 2) + pow(b.snf - snf, 2);
      return da.compareTo(db);
    });

    return same.first.rate;
  }
}
