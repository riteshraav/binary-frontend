import 'dart:io';
import 'package:excel/excel.dart';
import 'package:hive/hive.dart';
import '../model/rate_entry.dart';


class ExcelImportService {
  /// Expected columns (any order, case-insensitive): animal, fat, snf, rate
  /// animal values: "cow" / "buffalo" (you can also accept Marathi and map to these)
  static Future<int> importRatesFromExcel(File file) async {
    final bytes = await file.readAsBytes();
    final excel = Excel.decodeBytes(bytes);

    final box = Hive.box<RateEntry>('rateBox');
    int inserted = 0;

    for (final table in excel.tables.keys) {
      final sheet = excel.tables[table];
      if (sheet == null) continue;
      if (sheet.rows.isEmpty) continue;

      // Header map
      final headerRow = sheet.rows.first;
      final Map<String, int> colIndex = {};
      for (int i = 0; i < headerRow.length; i++) {
        final v = headerRow[i]?.value?.toString().trim().toLowerCase() ?? '';
        if (v.isNotEmpty) colIndex[v] = i;
      }

      int? cAnimal = colIndex['animal'] ?? colIndex['type'] ?? colIndex['प्रकार'];
      int? cFat = colIndex['fat'] ?? colIndex['फॅट'];
      int? cSnf = colIndex['snf'] ?? colIndex['एसएनएफ'] ?? colIndex['snf%'];
      int? cRate = colIndex['rate'] ?? colIndex['दर'] ?? colIndex['price'];

      if ([cAnimal, cFat, cSnf, cRate].any((e) => e == null)) {
        // If no header, try fixed positions: A:animal, B:fat, C:snf, D:rate
        cAnimal ??= 0;
        cFat ??= 1;
        cSnf ??= 2;
        cRate ??= 3;
      }

      for (int r = 1; r < sheet.maxRows; r++) {
        final row = sheet.row(r);
        if (row.isEmpty) continue;

        String animalRaw = (row[cAnimal!]?.value ?? '').toString().trim().toLowerCase();
        // Map Marathi synonyms to english keys
        if (animalRaw == 'गाय' || animalRaw == 'cow ') animalRaw = 'cow';
        if (animalRaw == 'म्हैस' || animalRaw == 'buffalo ') animalRaw = 'buffalo';

        if (!(animalRaw == 'cow' || animalRaw == 'buffalo')) continue;

        double? fat = _toD(row[cFat!]?.value);
        double? snf = _toD(row[cSnf!]?.value);
        double? rate = _toD(row[cRate!]?.value);

        if (fat == null || snf == null || rate == null) continue;

        await box.add(RateEntry(animal: animalRaw, fat: fat, snf: snf, rate: rate));
        inserted++;
      }
    }

    return inserted;
  }

  static double? _toD(dynamic v) {
    if (v == null) return null;
    if (v is num) return v.toDouble();
    final s = v.toString().replaceAll(',', '.').trim();
    return double.tryParse(s);
  }
}
